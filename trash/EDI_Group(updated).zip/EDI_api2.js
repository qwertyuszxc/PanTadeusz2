fetch('https://my.api.mockaroo.com/edi.json?key=12a6d260').then((data) =>{
    //console.log(data);
    return data.json();
}).then((objectData) => {
    console.log(objectData[0].Nickname);
    let tableData ='';
    objectData.map((values) => {
        tableData+=         `<tr>
        <td>${values.Nickname}</td>
        <td>${values.Active}</td>
        <td>${values.Real_Name}</td>
        <td>${values.Date_of_birth}</td>
        <td>${values.Country_of_birth}</td>
    </tr>`;
    });
    document.getElementById('table-body').innerHTML=tableData;
})
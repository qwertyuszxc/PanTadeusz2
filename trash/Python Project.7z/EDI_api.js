var xhttp = new XMLHttpRequest;

xhttp.open('GET','https://my.api.mockaroo.com/edi.json?key=12a6d260',true);
xhttp.send();
`
xhttp.onreadystatechange = function(){
    if(this.readyState == 4 && this.status == 200){
        var response =  JSON.parse(xhttp.responseText);


        var table = response.table;

        var item = '';

        for(var i = 0; i < .lenght; i++){

            item += `<li id='tableItem'> ${[i].Nickname}</li>`
        }

        document.getElementById('table').innerHTML = item;
    }
};
`
